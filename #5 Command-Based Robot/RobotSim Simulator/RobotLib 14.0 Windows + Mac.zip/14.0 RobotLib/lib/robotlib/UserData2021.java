package robotlib;

public enum UserData2021 {
    cameraIdx, frontLeftSpeed, frontRightSpeed, backLeftSpeed, backRightSpeed, frontLeftRotationSpeed,
    frontRightRotationSpeed, backLeftRotationSpeed, backRightRotationSpeed, shooterSpeed, feederSpeed, rollerSpeed
}