package robotlib;

public enum UserData2018 {
    cameraIdx, leftSpeed, rightSpeed, elevatorSpeed, leftIntakeSpeed, rightIntakeSpeed
}
