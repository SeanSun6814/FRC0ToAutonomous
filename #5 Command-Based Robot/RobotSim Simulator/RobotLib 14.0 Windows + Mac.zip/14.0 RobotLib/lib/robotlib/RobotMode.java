package robotlib;

public enum RobotMode {
    Disabled, Teleop, Auto, Practice, Test
}