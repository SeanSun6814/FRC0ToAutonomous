package robotlib;

public class Robot2021Consts {
    public static double TRACKWIDTH = 0.65;// m
    public static double WHEELBASE = 0.65;// m
    public static double kWheelCircumference = 0.13;// m
}
