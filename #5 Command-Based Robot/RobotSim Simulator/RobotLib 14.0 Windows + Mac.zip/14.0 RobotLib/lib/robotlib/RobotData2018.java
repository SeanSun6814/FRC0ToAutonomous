package robotlib;

public enum RobotData2018 {
    robot, version, time, axis1, axis2, axis3, axis4, button0, button1, button2, button3, button4, button5, robotAngle,
    leftDriveEncoder, rightDriveEncoder, elevatorEncoder
}