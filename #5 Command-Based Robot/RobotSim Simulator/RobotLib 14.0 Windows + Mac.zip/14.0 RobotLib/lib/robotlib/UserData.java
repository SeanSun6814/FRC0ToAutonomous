package robotlib;

public enum UserData {
    cameraIdx
}
